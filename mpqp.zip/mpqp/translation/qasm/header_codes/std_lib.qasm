include "stdgates.inc";
