"""In some cases, we need to manipulate unitary operations that are not defined
using native gates (by the corresponding unitary matrix for instance). For those
cases, you can use :class:`mpqp.core.instruction.gates.custom_gate.CustomGate`
to add your custom unitary operation to the circuit, which will be decomposed
and executed transparently."""

from __future__ import annotations

from copy import copy
from numbers import Complex
from typing import TYPE_CHECKING, Optional, Union

from mpqp.tools import Matrix

if TYPE_CHECKING:
    from qiskit._accelerate.circuit import Parameter
    from mpqp.core.circuit import QCircuit
    from sympy import Basic, Expr

from mpqp.core.instruction.gates.gate import Gate
from mpqp.core.instruction.gates.gate_definition import UnitaryMatrix
from mpqp.core.languages import Language


class CustomGate(Gate):
    """Custom gates allow you to define your own unitary gates.

    Args:
        matrix: The matrix describing the gate.
        targets: The qubits on which the gate operates.
        label: The label of the gate. Defaults to None.

    Raises:
        ValueError: the target qubits must be contiguous and in order, and must
            match the size of the matrix

        ValueError: Target qubits must be ordered and contiguous for a CustomGate.


    Example:
        >>> u = np.array([[0,-1],[1,0]])
        >>> cg = CustomGate(u, [0])
        >>> print(run(QCircuit([X(0), cg]), IBMDevice.AER_SIMULATOR))
        Result: IBMDevice, AER_SIMULATOR
          State vector: [-1, 0]
          Probabilities: [1, 0]
          Number of qubits: 1

    """

    def __init__(
        self,
        matrix: Matrix,
        targets: Union[list[int], int],
        label: Optional[str] = None,
    ):
        definition = UnitaryMatrix(matrix)
        if isinstance(targets, int):
            targets = [targets]
        self.definition = definition
        """See parameter description."""
        if definition.nb_qubits != len(targets):
            raise ValueError(
                f"Size of the targets ({len(targets)}) must match the number of qubits of the "
                f"UnitaryMatrix ({definition.nb_qubits})"
            )

        # 3M-TODO: add later the possibility to give non-contiguous and/or non-ordered target qubits for CustomGate,
        #  use the to_matrix() method inherited from Gate, maybe

        super().__init__(targets, label)

    @property
    def matrix(self) -> Matrix:
        # TODO: move this to `to_canonical_matrix` and check for the usages
        return self.definition.matrix

    @property
    def free_symbols(self) -> "set[Basic]":
        from sympy import Expr

        return set.union(
            set(),
            *[e.free_symbols for e in self.matrix.flatten() if isinstance(e, Expr)],
        )

    def to_matrix(self, desired_gate_size: int = 0):
        return self.matrix

    def to_canonical_matrix(self):
        return self.matrix

    def to_other_language(
        self,
        language: Language = Language.QISKIT,
        qiskit_parameters: Optional[set["Parameter"]] = None,
        printing: bool = False,
    ):
        if language == Language.QISKIT:
            from qiskit.circuit.library import UnitaryGate
            from sympy import Expr

            if qiskit_parameters is None:
                qiskit_parameters = set()
            gate_symbols = set().union(
                *(
                    elt.free_symbols
                    for elt in self.matrix.flatten()
                    if isinstance(elt, Expr)
                )
            )
            from mpqp.core.instruction.gates.native_gates import (
                _qiskit_parameter_adder,  # pyright: ignore[reportPrivateUsage]
            )

            for symbol in gate_symbols:
                if TYPE_CHECKING:
                    assert isinstance(symbol, Expr)
                _qiskit_parameter_adder(symbol, qiskit_parameters)

            if len(gate_symbols) > 0:
                if not printing:
                    raise ValueError(
                        "Custom gates defined with symbolic variables cannot be"
                        " exported to qiskit."
                    )
                from qiskit import QuantumCircuit

                dummy_circuit = QuantumCircuit(self.nb_qubits)
                dummy_circuit.id(0)
                return dummy_circuit.to_gate(
                    label=f"CustomGate({', '.join([str(s) for s in gate_symbols])})"
                )
            return UnitaryGate(self.matrix, label=self.label, check_input=False)
        elif language == Language.BRAKET:
            from sympy import Expr

            gate_symbols = set().union(
                *(
                    elt.free_symbols
                    for elt in self.matrix.flatten()
                    if isinstance(elt, Expr)
                )
            )

            if len(gate_symbols) > 0:
                if not printing:
                    raise ValueError(
                        "Custom gates defined with symbolic variables cannot be "
                        "exported to Braket for now (only numerical matrices are supported)."
                    )
                return None
            else:
                from braket.circuits import Instruction as BraketInstruction
                from braket.circuits.gates import Unitary as BraketUnitary

                return BraketInstruction(
                    operator=BraketUnitary(self.definition.matrix),
                    target=self.targets,
                )
        elif language == Language.CIRQ:
            from cirq import MatrixGate

            return MatrixGate(matrix=self.matrix, name=self.label, unitary_check=False)
            from cirq import MatrixGate

            return MatrixGate(matrix=self.matrix, name=self.label, unitary_check=False)

        elif language == Language.QASM2:
            from qiskit import QuantumCircuit, qasm2

            from mpqp.tools.circuit import replace_custom_gate

            nb_qubits = max(self.targets) + 1

            qiskit_circ = QuantumCircuit(nb_qubits)
            instr = self.to_other_language(Language.QISKIT)
            if TYPE_CHECKING:
                from qiskit.circuit.library import UnitaryGate

                assert isinstance(instr, UnitaryGate)

            qiskit_circ.unitary(
                instr,
                list(reversed(self.targets)),
                self.label,
            )

            circuit, gphase = replace_custom_gate(qiskit_circ, nb_qubits, self.targets)

            qasm_str = qasm2.dumps(circuit)
            qasm_lines = qasm_str.splitlines()

            instructions_only = [
                line
                for line in qasm_lines
                if not (
                    line.startswith("qreg")
                    or line.startswith("include")
                    or line.startswith("creg")
                    or line.startswith("OPENQASM")
                )
            ]
            return "\n".join(instructions_only), gphase
        else:
            raise NotImplementedError(f"Error: {language} is not supported")

    def __repr__(self) -> str:
        label = f", \"{self.label}\"" if self.label else ""
        return f"CustomGate({repr(self.matrix)}, {self.targets}{label})"

    def decompose(self) -> "QCircuit":
        """Returns the circuit made of native gates equivalent to this gate.

        The circuit follows the quantum Shannon decomposition which decomposes any unitary matrix into Ry,Rz and CNOT gates.

        Example:
            >>> U = np.array([[0,1], [1,0]])
            >>> gate = CustomGate(U, [0])
            >>> print(gate.decompose()) # doctest: +NORMALIZE_WHITESPACE
            global phase: π/2
               ┌─────────┐┌───────┐┌──────────┐
            q: ┤ Rz(π/2) ├┤ Ry(π) ├┤ Rz(-π/2) ├
               └─────────┘└───────┘└──────────┘

        """
        from mpqp.tools.unitary_decomposition import quantum_shannon_decomposition

        # non ordered targets
        if any(
            self.targets[i + 1] < self.targets[i] for i in range(len(self.targets) - 1)
        ):
            from copy import deepcopy

            from mpqp.tools import rearrange_matrix
            import warnings

            warnings.warn(
                "In order to decompose a CustomGate with non ordered targets, the matrix gets copied and ordered according to the targets provided."
            )
            targets = deepcopy(self.targets)
            targets.sort()

            return quantum_shannon_decomposition(
                rearrange_matrix(self.matrix, self.targets, do_copy=True), targets
            )

        return quantum_shannon_decomposition(self.matrix, self.targets)

    def subs(self, values: "dict[Expr | str, Complex]") -> CustomGate:
        res = copy(self)
        res.definition = res.definition.subs(values)
        return res
