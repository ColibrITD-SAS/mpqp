"""Observables can be defined using linear combinations of Pauli operators,
these are called "Pauli strings". In ``mpqp``, a :class:`PauliString` is a
linear combination of :class:`PauliStringMonomial` which are themselves
combinations (tensor products) of :class:`PauliStringAtom`. :class:`PauliString`
can be added, subtracted and tensored together, as well as multiplied by scalars."""

from __future__ import annotations

from copy import deepcopy
from enum import Enum, auto
from functools import reduce
from numbers import Real
from operator import mul
from typing import TYPE_CHECKING, Any, Literal, Optional, Union, overload

import numpy as np
import numpy.typing as npt
from typing_extensions import Never

from mpqp.core.instruction.gates.gate import SingleQubitGate
from mpqp.core.instruction.gates.native_gates import H, S_dagger
from mpqp.core.languages import Language
from mpqp.tools import NumberQubitsError, format_element
from mpqp.tools.generics import Matrix
from mpqp.tools.maths import atol, is_power_of_two, rtol

if TYPE_CHECKING:
    from braket.circuits.observables import Observable as BraketObservable
    from braket.circuits.observables import Sum as BraketSum
    from braket.circuits.observables import TensorProduct
    from cirq.circuits.circuit import Circuit as CirqCircuit
    from cirq.ops.gate_operation import GateOperation as CirqGateOperation
    from cirq.ops.linear_combinations import PauliSum as CirqPauliSum
    from cirq.ops.pauli_string import PauliString as CirqPauliString
    from cirq.ops.raw_types import Qid
    from qat.core.wrappers.observable import Term
    from qiskit.quantum_info import SparsePauliOp
    from sympy import Basic, Expr

    Coef = Union[Real, float, Expr, Basic]


class CommutingTypes(Enum):
    """Enum regrouping the types of commutation supported by the PauliStrings."""

    FULL = auto()
    QUBITWISE = auto()


class GroupingMethods(Enum):
    """Enum regrouping the different Pauli grouping algorithms."""

    GREEDY = auto()
    COLORING_GREEDY = auto()
    COLORING_SF = auto()
    COLORING_LF = auto()
    COLORING_RECURSIVE_LF = auto()
    COLORING_DB = auto()
    COLORING_DSATUR = auto()
    CLIQUE_REMOVING = auto()
    QISKIT_COLORING_GREEDY = auto()


class PauliString:
    """Represents a Pauli string, a linear combination of Pauli monomials.

    Note that as a user of our library, you would most likely never need to
    directly call this class. Instead, we advise you to build the Pauli strings
    you need from the atom we provide (see the example bellow).

    Args:
        monomials : List of Pauli monomials defining the PauliString.

    Example:
        >>> pI @ pZ+ 2 * pY@ pI + pX@ pZ
        pI@pZ + 2*pY@pI + pX@pZ

    """

    def __init__(self, monomials: Optional[list["PauliStringMonomial"]] = None):
        self._monomials: list[PauliStringMonomial] = []

        if monomials is not None:
            for mono in monomials:
                if isinstance(mono, PauliStringAtom):
                    mono = PauliStringMonomial(1, [mono])
                self._monomials.append(mono)

        self._initial_nb_qubits = (
            self._monomials[0].nb_qubits if len(self._monomials) != 0 else 0
        )

        for mono in self._monomials:
            if mono.nb_qubits != self._initial_nb_qubits:
                raise ValueError(
                    f"Non homogeneous sizes for given PauliStrings: {monomials}"
                )

    @property
    def monomials(self) -> list[PauliStringMonomial]:
        """Monomials of the PauliString."""
        return self._monomials

    @property
    def nb_qubits(self) -> int:
        """Number of qubits associated with the PauliString."""
        return (
            self._monomials[0].nb_qubits
            if len(self._monomials) != 0
            else self._initial_nb_qubits
        )

    @staticmethod
    def from_str(compact_str: str, dict_value: Optional[dict[str, Coef]] = None):
        """Construct a :class:`PauliString` from a string representation.

        Args:
            compact_str: A representation of one or more Pauli terms.
            dict_value: Replacements to substitute symbolic coefficients.

        Returns:
            The corresponding Pauli string.

        Examples:
            >>> PauliString.from_str("X")
            pX
            >>> PauliString.from_str("-YZ")
            -1*pY@pZ
            >>> PauliString.from_str("a*X", dict_value={"a": 0.5})
            0.5*pX
            >>> PauliString.from_str("2*pX + 3*Y")
            (2*p)*pX + 3*pY

        """
        import re

        from sympy import sympify

        pattern = re.compile(r'([^IXYZ]+)?([IXYZ]+)')

        monomials: list[PauliStringMonomial] = []
        for match in pattern.finditer(compact_str.replace(" ", "")):
            coef_str, atoms_str = match.groups()

            if coef_str is None or coef_str == '' or coef_str == '+':
                coef = 1
            elif coef_str == '-':
                coef = -1
            else:
                coef_str = coef_str.rstrip('*')
                coef_str = re.sub(r'(\d)([a-zA-Z])', r'\1*\2', coef_str)
                coef_str = re.sub(r'([a-zA-Z])(\d)', r'\1*\2', coef_str)
                coef = sympify(coef_str)
                if dict_value:
                    coef = coef.subs(
                        dict_value  # pyright: ignore[reportArgumentType, reportCallIssue]
                    )

            atoms_dict = {
                "I": pI,
                "X": pX,
                "Y": pY,
                "Z": pZ,
            }
            monomials.append(
                PauliStringMonomial(coef, [atoms_dict[atom] for atom in atoms_str])
            )
        if len(monomials) == 1:
            return monomials[0]
        return PauliString(monomials)

    def _non_null_str(self):
        from sympy import Expr

        return str(self._monomials[0]) + "".join(
            (
                f" - {-m}"
                if not isinstance(m.coef, Expr)
                and m.coef < 0  # pyright: ignore[reportOperatorIssue]
                else f" + {m}"
            )
            for m in self._monomials[1:]
        )

    def __str__(self):
        sorted_ps = self.round().simplify().sorted_monomials()
        return "0" if len(sorted_ps._monomials) == 0 else sorted_ps._non_null_str()

    def __repr__(self):
        return "PauliString()" if len(self._monomials) == 0 else self._non_null_str()

    def build_repr(self):
        return (
            "PauliString()"
            if len(self._monomials) == 0
            else f"PauliString({repr(self._monomials)})"
        )

    def __pos__(self) -> "PauliString":
        return deepcopy(self)

    def __neg__(self) -> "PauliString":
        return -1 * self

    def __iadd__(self, other: "PauliString") -> "PauliString":
        if len(self.monomials) != 0:
            if not all([mono.nb_qubits == self.nb_qubits for mono in other.monomials]):
                raise ValueError(
                    f"Non homogeneous sizes for given PauliStrings: {(self, other)}"
                )
        else:
            self._initial_nb_qubits = other.nb_qubits
        self._monomials.extend(deepcopy(other.monomials))
        return self

    def __add__(self, other: "PauliString") -> "PauliString":
        res = deepcopy(self)
        res += other
        return res

    def __isub__(self, other: "PauliString") -> "PauliString":
        self += -1 * other
        return self

    def __sub__(self, other: "PauliString") -> "PauliString":
        return self + (-1) * other

    def __imul__(self, other: "Coef") -> "PauliString":
        for i, mono in enumerate(self._monomials):
            if isinstance(mono, PauliStringAtom):
                self.monomials[i] = PauliStringMonomial(atoms=[mono])
            self.monomials[i] *= other
        return self

    def __mul__(self, other: "Coef") -> "PauliString":
        res = deepcopy(self)
        res *= other
        return res

    def __rmul__(self, other: "Coef") -> "PauliString":
        return self * other

    def __itruediv__(self, other: "Coef") -> "PauliString":
        self *= 1 / other  # pyright: ignore[reportOperatorIssue]
        return self

    def __truediv__(self, other: "Coef") -> "PauliString":
        return self * (1 / other)  # pyright: ignore[reportOperatorIssue]

    def __imatmul__(self, other: "PauliString") -> "PauliString":
        self._monomials = [
            mono for s_mono in self.monomials for mono in (s_mono @ other).monomials
        ]
        return self

    def __matmul__(self, other: "PauliString") -> "PauliString":
        res = deepcopy(self)
        res @= other
        return res

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, PauliString):
            return False

        return self.to_dict() == other.to_dict()

    def subs(self, values: dict[Expr | str, Real]) -> PauliString:
        r"""Substitute the coef of the pauli sting with values for each of the
        specified coef. Optionally also remove all symbolic variables such
        as `\pi` (needed for example for circuit execution).

        Since we use ``sympy`` for the gate parameters, the ``values`` can in fact be
        anything the ``subs`` method from ``sympy`` would accept.

        Args:
            values: Mapping between the variables and the replacing values.

        Returns:
            The pauli sting with the replaced parameters.

        Examples:
            >>> theta, k = symbols("θ k")
            >>> ps = theta * pI @ pX+ k * pZ@ pY
            >>> ps
            (θ)*pI@pX + (k)*pZ@pY
            >>> ps.subs({theta: np.pi, k: 1})
            3.1415926536*pI@pX + pZ@pY

        """
        new_pauli_string = PauliString()
        for monomial in self.monomials:
            substituted_monomial = monomial.subs(values)
            new_pauli_string += substituted_monomial
        return new_pauli_string

    def simplify(self, inplace: bool = False, precision: int = 10) -> PauliString:
        """Simplifies the Pauli string by combining identical terms and removing
        terms with null coefficients. When all terms annihilate themselves, we
        return an empty PauliString with a number of qubits corresponding to the
        initial one.

        Args:
            inplace: Indicates if ``self`` should be updated in addition of a
                new Pauli string being returned.
            precision: Maximum number of digits to keep.

        Returns:
            The simplified version of the Pauli string.

        Example:
            >>> (pI @ pI - 2 *pI @ pI + pZ@ pI - pZ@ pI).simplify()
            -1*pI@pI

        """
        res = PauliString()
        res._initial_nb_qubits = self.nb_qubits
        for unique_mono_atoms in {tuple(mono.atoms) for mono in self.monomials}:
            coef = format_element(
                sum(  # pyright: ignore[reportCallIssue]
                    [
                        mono.coef
                        for mono in self.monomials
                        if mono.atoms == list(unique_mono_atoms)
                    ]  # pyright: ignore[reportArgumentType]
                ),
                precision=precision,
            )
            if TYPE_CHECKING:
                assert isinstance(coef, Coef)
            if coef != 0:
                res.monomials.append(PauliStringMonomial(coef, list(unique_mono_atoms)))

        if inplace:
            self._monomials = res.monomials
        return res

    def round(self, max_digits: int = 4) -> PauliString:
        """Rounds the coefficients of the PauliString to a specified number of
        decimals.

        Args:
            max_digits: Number of decimal places to round the coefficients to.

        Returns:
            The Pauli string with coefficients rounded to the specified number of
            decimals.

        Example:
            >>> ps = 0.6875 * pI @ pI + 0.1275 * pI @ pZ
            >>> ps.round(1)
            0.7*pI@pI + 0.1*pI@pZ

        """
        from sympy import Basic, Expr

        res = PauliString()
        res._initial_nb_qubits = self.nb_qubits
        for mono in self.monomials:
            coef: "Coef" = format_element(mono.coef)  # type: ignore[reportArgumentType]
            if isinstance(coef, (Expr, Basic)):
                res.monomials.append(PauliStringMonomial(mono.coef, mono.atoms))
            else:
                coef = float(np.round(float(coef), max_digits))
                if coef != 0:
                    res.monomials.append(PauliStringMonomial(coef, mono.atoms))
        return res

    def sorted_monomials(self) -> PauliString:
        """Creates a new Pauli string with the same monomials but sorted in
        monomial alphabetical ascending order (and the coefficients are not
        taken into account).

        Returns:
            The Pauli string with its monomials sorted.

        Example:
            >>> (2*pI@pZ + .5*pI@pX + pX@pY).sorted_monomials()
            0.5*pI@pX + 2*pI@pZ + pX@pY
        """
        return PauliString(
            sorted(self.monomials, key=lambda m: tuple(str(atom) for atom in m.atoms))
        )

    def to_matrix(self) -> Matrix:
        """Converts the PauliString to a matrix representation.

        Returns:
            Matrix representation of the Pauli string.

        Example:
            >>> pprint((pI + pZ).to_matrix())
            [[2, 0],
             [0, 0]]

        """
        self.simplify(inplace=True)
        size = 2**self.nb_qubits
        return sum(
            map(lambda m: m.to_matrix(), self.monomials),
            start=np.zeros((size, size), dtype=np.complex128),
        )

    def commutes_with(self, other: PauliString) -> bool:
        """
        3M-TODO: Determine EFFICIENTLY if this pauli string is commuting with the one in parameter.
        Args:
            other:

        Returns:


        """
        raise NotImplementedError()

    @staticmethod
    def from_matrix(
        matrix: Matrix, method: Literal["ptdr", "trace"] = "ptdr"
    ) -> PauliString:
        """Constructs a PauliString from a matrix.

        Args:
            matrix: Matrix from which the PauliString is generated.
            method: String indicating which Pauli decomposition method is used.
                "ptdr" refers to the tree-based decomposition algorithm (see
                :func:`~mpqp.tools.obs_decomposition.decompose_hermitian_matrix_ptdr`.),
                and "trace" to the one computing the trace of the observable
                with each possible monomial (naive method).

        Returns:
            Pauli string corresponding to the Pauli decomposition of the matrix
            in parameter.

        Raises:
            ValueError: If the input matrix is not square or its dimensions are
                not a power of 2.

        Example:
            >>> PauliString.from_matrix(np.array([[0, 1], [1, 2]]))
            pI + pX - pZ

        """

        if method == "ptdr":
            from mpqp.tools.obs_decomposition import decompose_hermitian_matrix_ptdr

            return decompose_hermitian_matrix_ptdr(matrix)

        elif method == "trace":
            if matrix.shape[0] != matrix.shape[1]:
                raise ValueError("Input matrix must be square.")

            if not is_power_of_two(matrix.shape[0]):
                raise ValueError("Matrix dimensions must be a power of 2.")
            num_qubits = int(np.log2(matrix.shape[0]))

            # Return the ordered Pauli basis for the n-qubit Pauli basis.
            pauli_1q = [PauliStringMonomial(1, [atom]) for atom in [pI, pX, pY, pZ]]
            basis = pauli_1q
            for _ in range(num_qubits - 1):
                basis = [p1 @ p2 for p1 in basis for p2 in pauli_1q]

            pauli_list = PauliString()
            for i, mat in enumerate(basis):
                coeff = (np.trace(mat.to_matrix().dot(matrix)) / (2**num_qubits)).real
                if not np.isclose(coeff, 0, atol=atol, rtol=rtol):
                    mono = basis[i] * coeff
                    pauli_list += mono

            if len(pauli_list.monomials) == 0:
                pauli_list.monomials.append(
                    PauliStringMonomial(0, [pI for _ in range(num_qubits)])
                )
            return pauli_list
        else:
            raise ValueError(
                f"Unexpected observable matrix decomposition method name {method}."
            )

    @staticmethod
    def from_diagonal_elements(
        diagonal_elements: list[float] | npt.NDArray[np.float64],
        method: Literal["walsh", "ptdr"] = "walsh",
    ) -> PauliString:
        """Create a PauliString from the diagonal elements of a diagonal
        observable, by using decomposition algorithms in the Pauli basis.

        Currently, two different methods are available: "walsh" and "ptdr".
        The first one is based on the computation of a walsh-hadamard matrix to
        retrieve the coefficients in front of the monomials that are
        combinations of ``I`` and ``Z``. The second is an adaptation of the PTDR
        algorithm (Pauli Tree Decomposition Routine), see
        :func:`~mpqp.tools.obs_decomposition.decompose_diagonal_observable_ptdr`.

        Args:
            diagonal_elements: List of Real coefficients
            method: String used to specify the decomposition method. "walsh"  or
                "ptdr".

        Returns:
            The pauli decomposition of the given diagonal observable elements.

        Example:
            >>> PauliString.from_diagonal_elements([1, -1, 4, 2])
            1.5*pI@pI + pI@pZ - 1.5*pZ@pI
        """

        if not is_power_of_two(len(diagonal_elements)):
            raise ValueError(
                f"Size of diagonal elements must be a power of 2, but got {len(diagonal_elements)}."
            )

        if method == "walsh":
            from mpqp.tools.obs_decomposition import (
                decompose_diagonal_observable_walsh_hadamard,
            )

            return decompose_diagonal_observable_walsh_hadamard(diagonal_elements)

        elif method == "ptdr":
            from mpqp.tools.obs_decomposition import decompose_diagonal_observable_ptdr

            return decompose_diagonal_observable_ptdr(diagonal_elements)
        else:
            raise ValueError(
                f"Unexpected observable matrix decomposition method name {method}."
            )

    @staticmethod
    def _get_dimension_cirq_pauli(
        pauli: Union[CirqPauliSum, CirqPauliString, CirqGateOperation],
    ):
        from cirq.ops.gate_operation import GateOperation as CirqGateOperation
        from cirq.ops.linear_combinations import PauliSum as CirqPauliSum
        from cirq.ops.pauli_string import PauliString as CirqPauliString

        dimension = 0
        if isinstance(pauli, CirqPauliSum):
            for term in pauli:
                for qubit, _ in term.items():
                    nb_qubits = (
                        int(qubit.x)
                        if hasattr(qubit, "x")
                        else int(qubit.name.split("_")[1])
                    )
                    dimension = max(dimension, nb_qubits + 1)
        elif isinstance(pauli, CirqPauliString):
            for qubit in pauli.qubits:
                nb_qubits = (
                    int(qubit.x)
                    if hasattr(qubit, "x")
                    else int(qubit.name.split("_")[1])
                )
                dimension = max(dimension, nb_qubits + 1)
        elif isinstance(pauli, CirqGateOperation):
            for line_qubit in pauli._qubits:
                nb_qubits = int(line_qubit.x)
                dimension = max(dimension, nb_qubits + 1)
        return dimension

    @staticmethod
    def _from_cirq(
        pauli: Union[CirqPauliSum, CirqPauliString, CirqGateOperation],
        min_dimension: int = 1,
    ) -> PauliString:
        from cirq.ops.gate_operation import GateOperation as CirqGateOperation
        from cirq.ops.identity import I as Cirq_I
        from cirq.ops.linear_combinations import PauliSum as CirqPauliSum
        from cirq.ops.pauli_gates import X as Cirq_X
        from cirq.ops.pauli_gates import Y as Cirq_Y
        from cirq.ops.pauli_gates import Z as Cirq_Z
        from cirq.ops.pauli_string import PauliString as CirqPauliString

        ps_mapping = {Cirq_X: pX, Cirq_Y: pY, Cirq_Z: pZ, Cirq_I: pI}

        num_qubits = max(PauliString._get_dimension_cirq_pauli(pauli), min_dimension)
        pauli_string = PauliString()

        def process_term(term: CirqPauliString, pauli_string: PauliString):
            coef = term.coefficient.real
            monomial = [pI] * num_qubits
            for qubit, op in term.items():
                index = (
                    int(qubit.x)
                    if hasattr(qubit, "x")
                    else int(qubit.name.split("_")[1])
                )
                monomial[index] = ps_mapping[op]
            pauli_string += PauliStringMonomial(coef, monomial)

        if isinstance(pauli, CirqPauliSum):
            for term in pauli:
                process_term(term, pauli_string)
        elif isinstance(pauli, CirqPauliString):
            process_term(pauli, pauli_string)
        elif isinstance(pauli, CirqGateOperation):
            monomial = [pI] * num_qubits
            for line_qubit in pauli._qubits:
                index = int(line_qubit.x)
                monomial[index] = ps_mapping[pauli._gate]
            pauli_string += PauliStringMonomial(1, monomial)

        return pauli_string

    @staticmethod
    def _from_qiskit(
        pauli: SparsePauliOp,
    ) -> PauliString:
        pauli_string = PauliString()
        for pauli_str, coef in pauli.to_list():
            monomial = PauliStringMonomial()
            for atom in pauli_str:
                monomial = monomial @ _pauli_atom_dict[atom]
            monomial *= coef.real
            pauli_string += monomial
        return pauli_string

    @staticmethod
    def _from_braket(
        pauli: BraketObservable,
    ) -> PauliString:
        from braket.circuits.observables import I as Braket_I
        from braket.circuits.observables import Sum as BraketSum
        from braket.circuits.observables import TensorProduct
        from braket.circuits.observables import X as Braket_X
        from braket.circuits.observables import Y as Braket_Y
        from braket.circuits.observables import Z as Braket_Z

        def tensor_product_to_pauli_sting(pauli: TensorProduct):
            monomial = PauliStringMonomial()
            for atom in pauli.factors:
                monomial @= _pauli_atom_dict[atom.ascii_symbols[0]]
            monomial *= pauli.coefficient
            return monomial

        if isinstance(pauli, BraketSum):
            pauli_str = PauliString()
            for tensor_product in pauli.summands:
                if isinstance(tensor_product, TensorProduct):
                    pauli_str += tensor_product_to_pauli_sting(tensor_product)
                elif isinstance(
                    tensor_product, (Braket_I, Braket_X, Braket_Y, Braket_Z)
                ):
                    pauli_str += _pauli_atom_dict[tensor_product.ascii_symbols[0]]
                else:
                    raise NotImplementedError(
                        f"Unsupported input type: {type(tensor_product)}."
                    )
            return pauli_str
        elif isinstance(pauli, TensorProduct):
            return tensor_product_to_pauli_sting(pauli)
        elif isinstance(pauli, (Braket_I, Braket_X, Braket_Y, Braket_Z)):
            return _pauli_atom_dict[pauli.ascii_symbols[0]]
        else:
            raise NotImplementedError(f"Unsupported input type: {type(pauli)}.")

    @staticmethod
    def _from_my_qml(
        pauli: Term,
        min_dimension: int = 0,
    ) -> PauliStringMonomial:
        min_dimension = (
            max(min_dimension, max(pauli.qbits) + 1)
            if len(pauli.qbits) > 0
            else min_dimension
        )
        monomial = [pI] * min_dimension
        for index, atom in enumerate(pauli.op):
            monomial[pauli.qbits[index]] = _pauli_atom_dict[atom]
        return PauliStringMonomial(pauli.coeff, monomial)

    @staticmethod
    def from_other_language(  # TODO: better typing using overloads
        pauli: Union[
            SparsePauliOp,
            BraketObservable,
            TensorProduct,
            list[Term],
            Term,
            CirqPauliSum,
            CirqPauliString,
            list[CirqPauliString],
            CirqGateOperation,
        ],
        min_dimension: int = 1,
    ) -> PauliString | list[PauliString]:
        """Convert pauli objects from other quantum SDKs to :class:`PauliString`.

        args:
            pauli: The pauli object(s) to be converted.
            min_dimension: Minimal dimension of the resulting Pauli string.

        Returns:
            The converted :class:`PauliString`. If the input is a list, the
            output will be a list of :class:`PauliString`.

        Examples:
            >>> from cirq import LineQubit, PauliSum, X as Cirq_X, Y as Cirq_Y, Z as Cirq_Z # doctest: +CIRQ
            >>> a, b, c = LineQubit.range(3) # doctest: +CIRQ
            >>> cirq_ps = 0.5 * Cirq_Z(a) * 0.5 * Cirq_Y(b) + 2 * Cirq_X(c) # doctest: +CIRQ
            >>> PauliString.from_other_language(cirq_ps) # doctest: +CIRQ
            0.25*pZ@pY@pI + 2*pI@pI@pX

            >>> from braket.circuits.observables import ( # doctest: +BRAKET
            ...     Sum as BraketSum,
            ...     I as Braket_I,
            ...     X as Braket_X,
            ...     Y as Braket_Y,
            ...     Z as Braket_Z,
            ... )
            >>> braket_ps = 0.25 * Braket_Z() @ Braket_Y() @ Braket_I() + 2 * Braket_I() @ Braket_I() @ Braket_X() # doctest: +BRAKET
            >>> PauliString.from_other_language(braket_ps) # doctest: +BRAKET
            0.25*pZ@pY@pI + 2*pI@pI@pX

            >>> from qiskit.quantum_info import SparsePauliOp
            >>> qiskit_ps = SparsePauliOp(["IIX", "ZYI"], coeffs=[2.0 + 0.0j, 0.25 + 0.0j])
            >>> PauliString.from_other_language(qiskit_ps)
            2*pI@pI@pX + 0.25*pZ@pY@pI


            >>> from qat.core.wrappers.observable import Term # doctest: +MYQLM
            >>> my_qml_ps = [Term(0.25, "ZY", [0, 1]), Term(2, "X", [2])] # doctest: +MYQLM
            >>> PauliString.from_other_language(my_qml_ps) # doctest: +MYQLM
            0.25*pZ@pY@pI + 2*pI@pI@pX

        """
        if isinstance(pauli, list):
            if len(pauli) == 0:
                return PauliString()
            elif any(not isinstance(p, type(pauli[0])) for p in pauli):
                raise ValueError(
                    "Cannot parse non-homogeneous types when `pauli` is a `list`."
                )
        from mpqp.environment.var_cache import (
            InstalledProviders,
            _INSTALLED_MPQP_PROVIDERS,  # pyright: ignore[reportPrivateUsage]
        )

        if InstalledProviders.QISKIT in _INSTALLED_MPQP_PROVIDERS:
            from qiskit.quantum_info import SparsePauliOp

            if isinstance(pauli, SparsePauliOp):
                return PauliString._from_qiskit(pauli)

        if InstalledProviders.BRAKET in _INSTALLED_MPQP_PROVIDERS:
            from braket.circuits.observables import Observable as BraketObservable

            if isinstance(pauli, BraketObservable):
                return PauliString._from_braket(pauli)

        if InstalledProviders.MY_QLM in _INSTALLED_MPQP_PROVIDERS:
            from qat.core.wrappers.observable import Term

            if isinstance(pauli, Term):
                return PauliString._from_my_qml(pauli)
            elif isinstance(pauli, list) and isinstance(pauli[0], Term):
                for term in pauli:
                    min_dimension = (
                        max(max(term.qbits) + 1, min_dimension)
                        if len(term.qbits) > 0
                        else min_dimension
                    )
                pauli_string = PauliString()
                for term in pauli:
                    pauli_string += PauliString._from_my_qml(term, min_dimension)
                return pauli_string

        if InstalledProviders.CIRQ in _INSTALLED_MPQP_PROVIDERS:
            from cirq.ops.gate_operation import GateOperation as CirqGateOperation
            from cirq.ops.linear_combinations import PauliSum as CirqPauliSum
            from cirq.ops.pauli_string import PauliString as CirqPauliString

            if isinstance(pauli, (CirqPauliSum, CirqPauliString, CirqGateOperation)):
                return PauliString._from_cirq(pauli, min_dimension)
            elif isinstance(pauli, list) and isinstance(pauli[0], CirqPauliString):
                min_dimension = max(
                    max(map(PauliString._get_dimension_cirq_pauli, pauli)),
                    min_dimension,
                )
                return [
                    PauliString._from_cirq(pauli_mono, min_dimension)
                    for pauli_mono in pauli
                ]

        raise NotImplementedError(
            f"Unsupported input type: {type(pauli)}, or sdk not installed."
        )

    @overload
    def to_other_language(
        self, language: Literal[Language.BRAKET]
    ) -> Union[BraketSum, TensorProduct]: ...
    @overload
    def to_other_language(
        self, language: Literal[Language.QISKIT]
    ) -> SparsePauliOp: ...
    @overload
    def to_other_language(self, language: Literal[Language.MY_QLM]) -> list[Term]: ...
    @overload
    def to_other_language(
        self, language: Literal[Language.CIRQ], circuit: Optional[CirqCircuit] = None
    ) -> Union[CirqPauliSum, CirqPauliString, list[CirqPauliString]]: ...
    @overload
    def to_other_language(
        self, language: Literal[Language.QASM2, Language.QASM3]
    ) -> Never: ...
    @overload
    def to_other_language(
        self, language: Language, circuit: Optional[CirqCircuit] = None
    ) -> Union[
        CirqPauliSum,
        CirqPauliString,
        list[CirqPauliString],
        SparsePauliOp,
        BraketSum,
        TensorProduct,
        list[Term],
    ]: ...

    def to_other_language(
        self, language: Language, circuit: Optional[CirqCircuit] = None
    ) -> Union[
        SparsePauliOp,
        BraketSum,
        TensorProduct,
        list[Term],
        Term,
        CirqPauliSum,
        CirqPauliString,
        list[CirqPauliString],
    ]:
        """Converts the pauli string to pauli string of another quantum
        programming language.

        Args:
            language: The target programming language.
            circuit: The Cirq circuit associated with the pauli string (required
                for ``cirq``).

        Returns:
            Depends on the target language.

        Example:
            >>> ps = pX@ pX@ pI + pI @ pY@ pI + pI @ pI @ pZ
            >>> print(ps.to_other_language(Language.CIRQ)) # doctest: +CIRQ
            1.000*X(q(0))*X(q(1))+1.000*Y(q(1))+1.000*Z(q(2))
            >>> for term in ps.to_other_language(Language.MY_QLM): # doctest: +MYQLM
            ...     print(term.op, term.qbits)
            XX [0, 1]
            Y [1]
            Z [2]
            >>> ps.to_other_language(Language.QISKIT)
            SparsePauliOp(['XXI', 'IYI', 'IIZ'],
                          coeffs=[1.+0.j, 1.+0.j, 1.+0.j])
            >>> for tensor in ps.to_other_language(Language.BRAKET).summands:  # doctest: +BRAKET
            ...     print(tensor.coefficient, "".join(a.name for a in tensor.factors))
            1 XXI
            1 IYI
            1 IIZ

        """

        if language == Language.QISKIT:
            from qiskit.quantum_info import SparsePauliOp

            pauli_string = []
            pauli_string_coef = []
            for mono in self.monomials:
                pauli_string.append("".join(atom.label for atom in mono.atoms))
                pauli_string_coef.append(mono.coef)
            return SparsePauliOp(pauli_string, np.array(pauli_string_coef))
        elif language == Language.MY_QLM:
            return [mono.to_other_language(language) for mono in self.monomials]
        elif language == Language.BRAKET:
            from braket.circuits.observables import Sum

            return Sum(
                [mono.to_other_language(Language.BRAKET) for mono in self.monomials]
            )

        elif language == Language.CIRQ:
            cirq_pauli_string = None
            for monomial in self.monomials:
                cirq_monomial = monomial.to_other_language(language, circuit)
                cirq_pauli_string = (
                    cirq_monomial
                    if cirq_pauli_string is None
                    else cirq_pauli_string + cirq_monomial
                )

            return cirq_pauli_string
        else:
            raise NotImplementedError(f"Unsupported language: {language}")

    def to_dict(self) -> dict[str, str]:
        """Converts the Pauli string to a dictionary representation with the
        keys being the Pauli monomials and the values the corresponding
        coefficients.

        Returns:
            Mapping representing the Pauli string.

        Example:
            >>> (1 * pI @ pZ+ 2 * pI @ pI).to_dict()
            {'pIpI': '2', 'pIpZ': '1'}

        """
        me = self.simplify(precision=255)
        result_dict: dict[str, "Coef"] = {}
        for mono in me.monomials:
            atom_str = "".join(str(atom) for atom in mono.atoms)
            if atom_str not in result_dict:
                result_dict[atom_str] = mono.coef
            else:
                coef: "Coef" = (
                    result_dict[atom_str]
                    + mono.coef  # pyright: ignore[reportOperatorIssue, reportAssignmentType]
                )
                result_dict[atom_str] = coef
        return {k: str(result_dict[k]) for k in sorted(result_dict)}

    def __hash__(self):
        monomials_as_tuples = tuple(
            tuple((atom.label for atom in mono.atoms) for mono in self.monomials)
        )
        return hash(monomials_as_tuples)

    def is_diagonal(self) -> bool:
        """Checks whether this pauli string has a diagonal representation, by checking if only ``I`` and ``Z`` Pauli
        operators appears in the monomials of the string.

        Returns:
            True if the observable represented by pauli string is diagonal.

        Examples:
            >>> (pI @ pX+ pZ@ pY- pY@ pX).is_diagonal()
            False
            >>> (pI @ pZ@ pI - 2* pZ@ pZ@ pZ+ pI @ pI @ pI).is_diagonal()
            True

        """

        return all([all([a == pI or a == pZ for a in m.atoms]) for m in self.monomials])

    def rearrange(self, targets: list[int], do_copy: bool = True) -> PauliString:
        """Rearranges elements (order of the atoms in the monomial) of the pauli
        string according to the targets.

        Args:
            targets: The list of unordered contiguous targets, (must contain 0).
            do_copy: If ``True`` will deepcopy the initial string ps.

        Examples:
            >>> ps = pX @ pI + pI @ pX
            >>> ps.rearrange([1,0])
            pI@pX + pX@pI
            >>> ps
            pX@pI + pI@pX
            >>> ps2 = pX @ pI
            >>> ps2.rearrange([1,0], False)
            pI@pX
            >>> ps2
            pI@pX
        """
        from mpqp.core.instruction.measurement.pauli_string import (
            PauliStringMonomial,
            pI,
        )

        if do_copy:
            from copy import deepcopy

            ps = deepcopy(self)
        else:
            ps = self

        def _reorder_inplace_monomial(mono: PauliStringMonomial):
            atoms = [pI] * len(mono.atoms)
            for source, destination in enumerate(targets):
                atoms[destination] = mono.atoms[source]
            mono._atoms = atoms  # pyright: ignore[reportPrivateUsage]

        if isinstance(ps, PauliStringMonomial):
            # this is needed because the monomials attribute of PauliStringMonomial
            # creates a new object, so if we rely on it it would actually not modify
            # the new object
            _reorder_inplace_monomial(ps)
            return ps

        for mono in ps.monomials:
            _reorder_inplace_monomial(mono)
        return ps


class PauliStringMonomial(PauliString):
    """Represents a monomial in a Pauli string, consisting of a coefficient and
    a list of PauliStringAtom objects.

    Args:
        coef: The coefficient of the monomial.
        atoms: The list of PauliStringAtom objects forming the monomial.
    """

    coef: Coef

    def __init__(
        self, coef: "Coef" = 1, atoms: Optional[list["PauliStringAtom"]] = None
    ):
        self.coef = coef
        """Coefficient of the monomial."""
        self._atoms = [] if atoms is None else atoms

    @property
    def atoms(self) -> list["PauliStringAtom"]:
        """The list of atoms in the monomial."""
        return self._atoms

    @property
    def nb_qubits(self) -> int:
        return len(self.atoms)

    @property
    def monomials(self) -> list["PauliStringMonomial"]:
        return [PauliStringMonomial(self.coef, self.atoms)]

    @property
    def positive_eigen_values(self) -> npt.NDArray[np.bool_]:
        """Return the eigen values associated with this Pauli monomial,
        stored as booleans for efficiency. True refers to +1 and False to -1.

        Example:
            >>> (pX@ pY@ pI).positive_eigen_values  # doctest: +NORMALIZE_WHITESPACE
            array([ True, True, False, False, False, False, True, True])
        """
        eigvals = reduce(np.kron, [a.eigen_values for a in self.atoms])
        return eigvals > 0

    def __deepcopy__(self, memo: Optional[dict[int, Any]] = None):
        """Create a deep copy of the object.

        Args:
            memo : A dictionary used by the deepcopy machinery to track
                already-copied objects and preserve object identity.
                Defaults to an empty dictionary if not provided.

        Returns:
            A new instance of the same type with recursively copied attributes.
            Specifically coef is deep-copied and atoms is shallow-copied.
        """
        if memo is None:
            memo = {}
        if id(self) in memo:
            return memo[id(self)]
        copied = type(self)(
            coef=deepcopy(self.coef, memo),
            atoms=self.atoms.copy(),
        )
        memo[id(self)] = copied
        return copied

    @property
    def name(self) -> str:
        """Returns the string associated to the monomial without the coefficient."""
        return f"{'@'.join(map(str, self.atoms))}"

    @property
    def short_name(self) -> str:
        """Returns the string associated to the monomial without the coefficient and tensor product symbol."""
        return f"{''.join(atom.label for atom in self.atoms)}"

    def __str__(self):
        from sympy import Expr

        coef = format_element(self.coef)
        if isinstance(coef, Expr):
            coef = f'({str(coef)})*'
        else:
            coef = f"{coef}*" if coef != 1 else ""
        return f"{coef}{'@'.join(map(str,self.atoms))}"

    def __repr__(self):
        return str(self)

    def build_repr(self):
        coef = "" if self.coef == 1 else f"{self.coef}, "
        if coef == "":
            atoms = f"{repr(self._atoms)}"
        else:
            atoms = f"atoms={repr(self._atoms)}"
        return f"PauliStringMonomial({coef}{atoms})"

    def to_matrix(self) -> Matrix:
        return (  # pyright: ignore[reportOperatorIssue,reportReturnType]
            reduce(
                np.kron,
                map(lambda a: a.to_matrix(), self.atoms),
                np.eye(1, dtype=np.complex128).tolist(),
            )
            * self.coef
        )

    def __iadd__(self, other: "PauliString"):
        for mono in other.monomials:
            if (
                len(self.monomials) != 0
                and mono.nb_qubits != self.monomials[0].nb_qubits
            ):
                raise ValueError(
                    f"Non homogeneous sizes for given PauliStrings: {(self, other)}"
                )
        res = PauliString([self])
        res.monomials.extend(deepcopy(other.monomials))
        return res

    def __add__(self, other: "PauliString") -> PauliString:
        res = deepcopy(self)
        res += other
        return res

    def __imul__(self, other: "Coef") -> PauliStringMonomial:
        new_coef: "Coef" = (
            self.coef * other
        )  # pyright: ignore[reportAssignmentType, reportOperatorIssue]
        self.coef = new_coef
        return self

    def __itruediv__(self, other: "Coef") -> PauliStringMonomial:
        new_coef: "Coef" = (
            self.coef
            / other  # pyright: ignore[reportOperatorIssue, reportAssignmentType]
        )
        self.coef = new_coef
        return self

    def __truediv__(self, other: "Coef") -> PauliStringMonomial:
        res = deepcopy(self)
        res /= other
        return res

    def __imatmul__(self, other: PauliString) -> PauliString:
        if isinstance(other, PauliStringAtom):
            self.atoms.append(other)
            return self
        elif isinstance(other, PauliStringMonomial):
            new_coef: "Coef" = (
                self.coef
                * other.coef  # pyright: ignore[reportOperatorIssue, reportAssignmentType]
            )
            self.coef = new_coef
            self.atoms.extend(other.atoms)
            return self
        else:
            res = deepcopy(other)
            res._monomials = [  # pyright: ignore[reportAttributeAccessIssue]
                self @ mono for mono in other.monomials
            ]
            return res

    def __matmul__(self, other: PauliString):
        res = deepcopy(self)
        res @= other
        return res

    def simplify(self, inplace: bool = False, precision: int = 10):
        return deepcopy(self)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PauliStringMonomial):
            for a1, a2 in zip(self.atoms, other.atoms):
                if a1 != a2:
                    return False
            return bool(self.coef == other.coef)
        return super().__eq__(other)

    def __hash__(self):
        atoms_as_tuples = tuple((atom.label for atom in self.atoms))
        return hash(atoms_as_tuples)

    def commutes_with(
        self, other: PauliString, method: CommutingTypes = CommutingTypes.FULL
    ) -> bool:
        """Checks wether this Pauli monomial commutes (full commutativity) with the Pauli monomial in parameter. This
        is done by checking that the number of anti-commuting atoms is even.

        Args:
            other: The Pauli monomial for which we want to check commutativity with this monomial.
            method: The type of commutation to be verified.

        Returns:
            True if this Pauli monomial commutes with the one in parameter.

        Examples:
            >>> (pI @ pX@ pY).commutes_with(pZ@ pY@ pX)
            True
            >>> (pX@ pZ@ pZ).commutes_with(pY@ pZ@ pI)
            False
            >>> (pX@ pZ@ pZ).commutes_with(pX@ pZ@ pZ)
            True
            >>> (pX@ pX).commutes_with(pY@ pY, CommutingTypes.FULL)
            True
            >>> (pX@ pX).commutes_with(pY@ pY, CommutingTypes.QUBITWISE)
            False

        """
        if not isinstance(other, PauliStringMonomial):
            raise NotImplementedError(
                f"Commutativity checking is only implemented for PauliStringMonomial in the current version."
            )

        if self.nb_qubits != other.nb_qubits:
            raise NumberQubitsError(
                f"Mismatch between {self.nb_qubits=} and {other.nb_qubits=}."
            )
        if method == CommutingTypes.QUBITWISE:
            return all(
                self.atoms[i].commutes_with(other.atoms[i])
                for i in range(self.nb_qubits)
            )
        elif method == CommutingTypes.FULL:
            return (
                sum(not a.commutes_with(b) for a, b in zip(self.atoms, other.atoms)) % 2
                == 0
            )
        else:
            raise NotImplementedError(
                f"This type of commutingType {method} is not implemented yet."
            )

    def subs(self, values: dict[Expr | str, Real]) -> PauliStringMonomial:
        r"""Substitutes the parameters of the instruction with complex values.
        Optionally, also removes all symbolic variables such as `\pi` (needed for
        circuit execution, for example).

        Since we use ``sympy`` for gate parameters, ``values`` can in fact be
        anything the ``subs`` method from ``sympy`` would accept.

        Args:
            values: Mapping between the variables and the replacing values.

        Returns:
            The circuit with the replaced parameters.

        Example:
            >>> theta = symbols("θ")
            >>> (theta * pI @ pX).subs({theta: np.pi})
            3.1415926536*pI@pX

        """
        from sympy import Expr

        from mpqp.tools.display import (
            _unpack_expr,  # pyright: ignore[reportPrivateUsage]
        )

        new_monomial = deepcopy(self)
        caster = lambda v: _unpack_expr(v) if isinstance(v, Expr) else v
        if isinstance(new_monomial.coef, Expr):
            new_coef: "Coef" = caster(
                new_monomial.coef.subs(
                    values  # pyright: ignore[reportArgumentType, reportCallIssue]
                )
            )
            new_monomial.coef = new_coef

        return new_monomial

    @overload
    def to_other_language(
        self, language: Literal[Language.BRAKET]
    ) -> Union[BraketSum, TensorProduct]: ...
    @overload
    def to_other_language(
        self, language: Literal[Language.QISKIT]
    ) -> SparsePauliOp: ...
    @overload
    def to_other_language(self, language: Literal[Language.MY_QLM]) -> list[Term]: ...
    @overload
    def to_other_language(
        self, language: Literal[Language.CIRQ], circuit: Optional[CirqCircuit] = None
    ) -> Union[CirqPauliSum, CirqPauliString, list[CirqPauliString]]: ...
    @overload
    def to_other_language(
        self, language: Literal[Language.QASM2, Language.QASM3]
    ) -> Never: ...
    @overload
    def to_other_language(
        self, language: Language, circuit: Optional[CirqCircuit] = None
    ) -> Union[
        CirqPauliSum,
        CirqPauliString,
        list[CirqPauliString],
        SparsePauliOp,
        BraketSum,
        TensorProduct,
        list[Term],
    ]: ...

    def to_other_language(
        self, language: Language, circuit: Optional[CirqCircuit] = None
    ):
        if language == Language.QISKIT:
            from qiskit.quantum_info import SparsePauliOp

            pauli_mono_str = "".join(atom.label for atom in self.atoms)
            return SparsePauliOp(pauli_mono_str, np.array(self.coef))
        elif language == Language.MY_QLM:
            from qat.core.wrappers.observable import Term

            pauli_mono_str = "".join(atom.label for atom in self.atoms)
            return Term(self.coef, pauli_mono_str, list(range(len(pauli_mono_str))))
        elif language == Language.BRAKET:

            from braket.circuits.observables import I as Braket_I
            from braket.circuits.observables import X as Braket_X
            from braket.circuits.observables import Y as Braket_Y
            from braket.circuits.observables import Z as Braket_Z

            pauli_gate_map = {
                "I": Braket_I,
                "X": Braket_X,
                "Y": Braket_Y,
                "Z": Braket_Z,
            }
            braket_sum = None
            for target, atom in enumerate(self.atoms):
                braket_sum = (
                    braket_sum @ pauli_gate_map[atom.label](target)
                    if braket_sum
                    else pauli_gate_map[atom.label](target)
                )
            if braket_sum is None:
                raise ValueError("Pauli monomial cannot be empty.")
            return self.coef * (braket_sum)  # pyright: ignore[reportOperatorIssue]
        elif language == Language.CIRQ:
            from cirq.devices.line_qubit import LineQubit

            if TYPE_CHECKING:
                from cirq.ops.identity import IdentityGate as CirqI
                from cirq.ops.pauli_gates import Pauli as CirqPauli
                from cirq.ops.pauli_string import (
                    PauliString as CirqPauliString,  # pyright: ignore[reportUnusedImport]
                )

            all_qubits = (
                LineQubit.range(self.nb_qubits)
                if circuit is None
                else sorted(
                    set(
                        qubit
                        for moment in circuit
                        for op in moment.operations
                        for qubit in op.qubits
                    )
                )
            )

            cirq_atoms: list[Union[CirqPauli, CirqI, CirqPauliString]] = [
                atom.to_other_language(Language.CIRQ, target=all_qubits[index])
                for index, atom in enumerate(self.atoms)
            ]
            return (  # pyright: ignore[reportOperatorIssue]
                reduce(mul, cirq_atoms)  # pyright: ignore[reportArgumentType]
                * self.coef
            )
        else:
            raise NotImplementedError(f"Unsupported language: {language}")


class PauliStringAtom(PauliStringMonomial):
    """Represents a single Pauli operator acting on a qubit in a Pauli string.

    Args:
        label: The label representing the Pauli operator.
        matrix: The matrix representation of the Pauli operator.
        eig_values: The eigenvalues associated with the Pauli operator.
        eig_vectors: A list of eigenvectors associated with the Pauli operator.
        basis_change: Basis change of the measurement associated with the Pauli operator.

    Raises:
        RuntimeError: New atoms cannot be created, you should use the available
            ones.

    Note:
        All the atoms are already initialized. Available atoms are (``PI``,
        ``PX``, ``PY``, ``PZ``).
    """

    __is_mutable = True

    def __init__(
        self,
        label: str,
        matrix: npt.NDArray[np.complex128],
        eig_values: list[int],
        eig_vectors: npt.NDArray[np.complex128],
        basis_change: list[type[SingleQubitGate]],
    ):
        if _allow_atom_creation:
            self.label = label
            self.matrix = matrix
            self._eig_vals = np.array(eig_values)
            self._eig_vecs = np.array(eig_vectors)
            self._basis_change = basis_change
            self.__is_mutable = False
        else:
            raise RuntimeError(
                "New atoms cannot be created, just use the given `PI`, `PX`, `PY` "
                "and `PZ`"
            )

    @property
    def nb_qubits(self) -> int:
        return 1

    @property
    def atoms(self) -> list["PauliStringAtom"]:
        """Atoms present. (needed for upward compatibility with
        :class:`PauliStringMonomial`)"""
        return [self]

    @property
    def coef(self) -> "Coef":  # pyright: ignore[reportIncompatibleVariableOverride]
        """Coefficient of the monomial."""
        return 1

    @property
    def monomials(self):
        return [PauliStringMonomial(self.coef, [a for a in self.atoms])]

    @property
    def eigen_values(self) -> npt.NDArray[np.bool_]:
        return self._eig_vals

    def __deepcopy__(self, memo: Optional[dict[int, Any]] = None):
        if memo is not None:
            memo[id(self)] = self
        return self

    def __setattr__(self, name: str, value: Any):
        if not self.__is_mutable:
            raise AttributeError("This object is immutable")
        super().__setattr__(name, value)

    def __str__(self):
        return f"p{self.label}"

    def __repr__(self):
        return str(self)

    def __itruediv__(self, other: "Coef") -> PauliStringMonomial:
        self = self / other
        return self

    def __truediv__(self, other: "Coef") -> PauliStringMonomial:
        return PauliStringMonomial(
            1 / other,  # pyright: ignore[reportOperatorIssue, reportArgumentType]
            [self],
        )

    def __imul__(self, other: "Coef") -> PauliStringMonomial:
        self = self * other
        return self

    def __mul__(self, other: "Coef") -> PauliStringMonomial:
        return PauliStringMonomial(other, [self])

    def __rmul__(self, other: "Coef") -> PauliStringMonomial:
        return PauliStringMonomial(other, [self])

    def __imatmul__(self, other: PauliString) -> PauliString:
        res = (
            PauliStringMonomial(1, [other])
            if isinstance(other, PauliStringAtom)
            else deepcopy(other)
        )
        if isinstance(res, PauliStringMonomial):
            res.atoms.insert(0, self)
        else:
            for i, mono in enumerate(res.monomials):
                res.monomials[i] = PauliStringMonomial(mono.coef, mono.atoms)
                res.monomials[i].atoms.insert(0, self)
        return res

    def __matmul__(self, other: PauliString):
        res = deepcopy(self)
        res @= other
        return res

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PauliStringAtom):
            return self.label == other.label
        else:
            return super().__eq__(other)

    def __call__(
        self, prefix_qubits: int, postfix_qubits: int = 0
    ) -> PauliStringMonomial:
        """Constructs a Pauli string monomial from the atom in question with
        identities before and after according the the arguments given.

        Args:
            prefix_qubits: The number of identities to add before the atom.
            postfix_qubits: The number of identities to add after the atom.

        Returns:
            The Pauli string monomial with the specified atom in the desired
            position, and identity atoms elsewhere.

        Examples:
            >>> pZ(3)
            pI@pI@pI@pZ
            >>> pX(0,2)
            pX@pI@pI

        """
        return PauliStringMonomial(
            1, [pI] * prefix_qubits + [self] + [pI] * postfix_qubits
        )

    def __hash__(self):
        return hash(self.label)

    def to_matrix(self) -> npt.NDArray[np.complex128]:
        return self.matrix

    def get_basis_change(self) -> list[type[SingleQubitGate]]:
        return self._basis_change

    def commutes_with(
        self, other: PauliString, method: CommutingTypes = CommutingTypes.FULL
    ) -> bool:
        """Determines whether this single-qubit Pauli operator commutes with the one in parameter. In this case, this
        can be done by simply checking if one of the atoms are identity, or if they are the same.

        Args:
            other: The single-qubit Pauli operator with which want to check the commutativity
            method: The type of commutation being checked, Only full commutativity is implemented
                for PauliStringAtom.

        Returns:
            True if the atoms commute, False otherwise.

        Examples:
            >>> pX.commutes_with(pX)
            True
            >>> pX.commutes_with(pY)
            False
            >>> pX.commutes_with(pI)
            True
            >>> pY.commutes_with(pZ)
            False
            >>> pI.commutes_with(pZ)
            True
        """
        if not isinstance(other, PauliStringAtom):
            raise ValueError(
                f"Expected a PauliStringAtom in parameter but got {type(other).__name__}"
            )
        if method == CommutingTypes.FULL:
            return other is pI or self is pI or self is other
        raise ValueError(
            f"PauliStringAtoms can only fully commutes with each others, instead received {method}"
        )

    @overload
    def to_other_language(
        self,
        language: Literal[Language.BRAKET],
        circuit: Optional[CirqCircuit] = None,
        target: Optional[Qid] = None,
    ) -> BraketSum: ...
    @overload
    def to_other_language(
        self,
        language: Literal[Language.QISKIT],
        circuit: Optional[CirqCircuit] = None,
        target: Optional[Qid] = None,
    ) -> SparsePauliOp: ...
    @overload
    def to_other_language(
        self,
        language: Literal[Language.MY_QLM],
        circuit: Optional[CirqCircuit] = None,
        target: Optional[Qid] = None,
    ) -> list[Term]: ...
    @overload
    def to_other_language(
        self,
        language: Literal[Language.CIRQ],
        circuit: Optional[CirqCircuit] = None,
        target: Optional[Qid] = None,
    ) -> Union[CirqPauliSum, CirqPauliString, list[CirqPauliString]]: ...
    @overload
    def to_other_language(
        self, language: Literal[Language.QASM2, Language.QASM3]
    ) -> Never: ...
    @overload
    def to_other_language(
        self,
        language: Language,
        circuit: Optional[CirqCircuit] = None,
        target: Optional[Qid] = None,
    ) -> Union[
        CirqPauliSum,
        CirqPauliString,
        list[CirqPauliString],
        SparsePauliOp,
        BraketSum,
        list[Term],
    ]: ...

    def to_other_language(
        self,
        language: Language,
        circuit: Optional[CirqCircuit] = None,
        target: Optional[Qid] = None,
    ):
        if language == Language.QISKIT:
            from qiskit.quantum_info import SparsePauliOp

            return SparsePauliOp(self.label)
        elif language == Language.MY_QLM:
            from qat.core.wrappers.observable import Term

            return Term(1.0, self.label, [0])
        elif language == Language.BRAKET:
            from braket.circuits.observables import I as Braket_I
            from braket.circuits.observables import X as Braket_X
            from braket.circuits.observables import Y as Braket_Y
            from braket.circuits.observables import Z as Braket_Z

            pauli_gate_map = {
                "I": Braket_I(0),
                "X": Braket_X(0),
                "Y": Braket_Y(0),
                "Z": Braket_Z(0),
            }
            return pauli_gate_map[self.label]
        elif language == Language.CIRQ:
            from cirq.devices.line_qubit import LineQubit
            from cirq.ops.identity import I as Cirq_I
            from cirq.ops.pauli_gates import X as Cirq_X
            from cirq.ops.pauli_gates import Y as Cirq_Y
            from cirq.ops.pauli_gates import Z as Cirq_Z

            pauli_gate_map = {
                "I": Cirq_I,
                "X": Cirq_X,
                "Y": Cirq_Y,
                "Z": Cirq_Z,
            }
            return pauli_gate_map[self.label](
                LineQubit(0) if target is None else target
            )
        else:
            raise NotImplementedError(f"Unsupported language: {language}")


_allow_atom_creation = True

pI = PauliStringAtom(
    "I",
    np.eye(2, dtype=np.complex128),
    [1, 1],
    np.array([[1, 0], [0, 1]], dtype=np.complex128),
    [],
)
r"""Pauli-I atom representing the identity operator in a Pauli monomial or string.
Matrix representation:
`\begin{pmatrix}1&0\\0&1\end{pmatrix}`
"""
pX = PauliStringAtom(
    "X",
    1 - np.eye(2, dtype=np.complex128),
    [1, -1],
    (1 / np.sqrt(2)) * np.array([[1, 1], [1, -1]], dtype=np.complex128),
    [H],
)
r"""Pauli-X atom representing the X operator in a Pauli monomial or string.
Matrix representation:
`\begin{pmatrix}0&1\\1&0\end{pmatrix}`

"""
pY = PauliStringAtom(
    "Y",
    np.fliplr(np.diag([-1j, 1j])).astype(np.complex128),
    [1, -1],
    (1 / np.sqrt(2)) * np.array([[1, 1j], [1, -1j]], dtype=np.complex128),
    [S_dagger, H],
)
r"""Pauli-Y atom representing the Y operator in a Pauli monomial or string.
Matrix representation:
`\begin{pmatrix}0&-i\\i&0\end{pmatrix}`
"""
pZ = PauliStringAtom(
    "Z",
    np.diag([1, -1]).astype(np.complex128),
    [1, -1],
    np.array([[1, 0], [0, 1]], dtype=np.complex128),
    [],
)
r"""Pauli-Z atom representing the Z operator in a Pauli monomial or string.
Matrix representation:
`\begin{pmatrix}1&0\\0&-1\end{pmatrix}`
"""

_pauli_atom_dict = {"I": pI, "X": pX, "Y": pY, "Z": pZ}
_allow_atom_creation = False
